<?php
include('session.php');
?>

<body>
     <div class="container"><br>
          <div class="row-fluid">
                <div class="span12">
                     <div class="span9">
                           <div class="alert alert-success">
                                 <h4>Solved Complain List</h4>
                           </div>
                           <legend></legend>
                           <table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" id="example">
                           <caption></caption>
                                    <thead>
                                           <tr>
                                              <th>Name</th>
                                              <th>Number</th>
                                              <th>Complain</th>
                                              <th>Complain No.</th>
                                              


                                              
                                           </tr>
                                     </thead>
                                     <tbody>
                                           <?php
                                                $query="SELECT * from complain where status='done' order by id desc" or die(mysqli_error($con));
                                                $sql=mysqli_query($con,$query)or die(mysqli_error($con));
                                                while($row=mysqli_fetch_array($sql)){
                                                
                                                $bnm=$row['nm'];
                                                $no=$row['no'];
                                                $msg=$row['cmp'];
                                                $com_no=$row['complain_no'];


                                            ?>
                                            <tr>
                                              <td><?php echo $bnm;?></td>
                                              <td><?php echo $no;?></td>
                                              <td><?php echo $msg;?></td>
                                              <td><?php echo $com_no;?></td>
                                              

                                              
                                          </tr>
                                          <?php
                                               include('modal_edit_admin.php');
                                               include('modal_delete_admin.php');
                                           } ?> 
                                      </tbody> 
                              </table>    
                         </div>
                         <?php include('session_sidebar.php'); ?>
                         <div class="well">
                              <a button class="btn btn-block btn-success" type="button" href="#addadmin" role="button"  data-toggle="modal"><i class="icon-edit icon-large"></i> Add Admin</button></a>
                         <?php include("modal_addadmin.php");?>
                         </div>
                   </div>
             </div>
       </div>
</body>
<?php   include('footer.php'); ?>