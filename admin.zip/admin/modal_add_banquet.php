<div id="addphotos" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
     <div class="modal-header">
          <div class="alert alert-gray">
               Add Banquet
          </div>
          <div class="modal-body"><hr>
               <form class="form-horizontal" method="POST" enctype="multipart/form-data">
                     <div class="control-group">
                           <label class="control-label" for="inputEmail">Banquet</label>
                                  <div class="controls">
                                       <input type="text" class="span10" id="inputEmail" name="bant" placeholder="Banquet"  class="span3">
                                  </div>
                     </div>
                     <div class="control-group">
                           <label class="control-label" for="inputEmail">City</label>
                                  <div class="controls">
                                       <input type="text" class="span10" id="inputEmail" name="city" placeholder="City"  class="span3">
                                  </div>
                     </div>
                     <div class="control-group">
                           <label class="control-label" for="inputEmail">Location</label>
                                  <div class="controls">
                                       <input type="text" class="span10" id="inputEmail" name="loca" placeholder="Location"  class="span3">
                                  </div>
                     </div>
                     <div class="control-group">
                           <label class="control-label" for="inputEmail">Title</label>
                                  <div class="controls">
                                       <input type="text" class="span10" id="inputEmail" name="title" placeholder="Title"  class="span3">
                                  </div>
                     </div>
                     <div class="control-group">
                           <label class="control-label" for="inputEmail">Paragraph 1</label>
                                  <div class="controls">
                                       <textarea class="span10" id="inputEmail" name="par1" placeholder=""  class="span3"></textarea>
                                  </div>
                     </div>
                     <div class="control-group">
                           <label class="control-label" for="inputEmail">Paragraph 2</label>
                                  <div class="controls">
                                       <textarea class="span10" id="inputEmail" name="par2" placeholder=""  class="span3"></textarea>
                                  </div>
                     </div>
                     <div class="control-group">
                           <label class="control-label" for="inputEmail">Paragraph 3</label>
                                  <div class="controls">
                                       <textarea class="span10" id="inputEmail" name="par3" placeholder=""  class="span3"></textarea>
                                  </div>
                     </div>
                     <div class="control-group">
                           <label class="control-label" for="inputEmail">Display Price : &#8377;</label>
                                  <div class="controls">
                                       <input type="text" class="span10" id="inputEmail" name="disp" placeholder="Display Price"  class="span3">
                                  </div>
                     </div>
                     <div class="control-group">
                           <label class="control-label" for="inputEmail">Banquet Price : &#8377;</label>
                                  <div class="controls">
                                       <input type="text" class="span10" id="inputEmail" name="banq" placeholder="Banquet Price"  class="span3">
                                  </div>
                     </div>
                     <div class="control-group">
                           <label class="control-label" for="inputEmail">Decoration Price : &#8377;</label>
                                  <div class="controls">
                                       <input type="text" class="span10" id="inputEmail" name="deco" placeholder="Decoration Price"  class="span3">
                                  </div>
                     </div>
                     <div class="control-group">
                          <label class="control-label" for="input01">Image 1</label>
                                 <div class="controls">
                                      <input type="file" name="image1" class="font"> 
                                 </div>
                     </div>
                     <div class="control-group">
                          <label class="control-label" for="input01">Image 2</label>
                                 <div class="controls">
                                      <input type="file" name="image2" class="font"> 
                                 </div>
                     </div>
                     <div class="control-group">
                          <label class="control-label" for="input01">Image 3</label>
                                 <div class="controls">
                                      <input type="file" name="image3" class="font"> 
                                 </div>
                     </div>
                     <div class="control-group">
                          <label class="control-label" for="input01">Image 4</label>
                                 <div class="controls">
                                      <input type="file" name="image4" class="font" > 
                                 </div>
                     </div>
                     <div class="control-group">
                          <label class="control-label" for="input01">Image 5</label>
                                 <div class="controls">
                                      <input type="file" name="image5" class="font" > 
                                 </div>
                     </div>
                     <div class="control-group">
                          <label class="control-label" for="input01">Image 6</label>
                                 <div class="controls">
                                      <input type="file" name="image6" class="font" > 
                                 </div>
                     </div>
                     <div class="control-group">
                          <label class="control-label" for="input01">Image 7</label>
                                 <div class="controls">
                                      <input type="file" name="image7" class="font" > 
                                 </div>
                     </div>
                     <div class="control-group">
                          <label class="control-label" for="input01">Image 8</label>
                                 <div class="controls">
                                      <input type="file" name="image8" class="font" > 
                                 </div>
                     </div>
                     <div class="control-group">
                          <label class="control-label" for="input01">Image 9</label>
                                 <div class="controls">
                                      <input type="file" name="image9" class="font" > 
                                 </div>
                     </div>
               </div>
               <div class="modal-footer">
                     <button name="saveff" type="submit" class="btn btn-success"><i class="icon-pencil"></i>&nbsp;Post</button>
                     <button class="btn" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i>&nbsp;Close</button>
              </form>  
      </div>
</div>
<?php
include('dbcon.php');
if(isset($_POST['saveff'])){
$banquet=$_POST['bant'];
$city=$_POST['city'];
$location=$_POST['loca'];
$title=$_POST['title'];
$para1=$_POST['par1'];
$para2=$_POST['par2'];
$para3=$_POST['par3'];
$disp=$_POST['disp'];
$banq=$_POST['banq'];
$deco=$_POST['deco'];

error_reporting(0);
$change="";
$abc="";
define ("MAX_SIZE","400");
function getExtension($str) {
         $i = strrpos($str,".");
         if (!$i) { return ""; }
         $l = strlen($str) - $i;
         $ext = substr($str,$i+1,$l);
         return $ext;
}
$errors=0;
if($_SERVER["REQUEST_METHOD"] == "POST"){
$g111=end(explode('.',$_FILES['image1']['name']));
$image1='banquet_'.md5(rand()).'.'.$g111;
$uploadedfile1 = $_FILES['image1']['tmp_name'];
   if ($image1){
             $filename = stripslashes($_FILES['image1']['name']);
             $extension = getExtension($filename);
           $extension = strtolower($extension);
           if (($extension != "jpg") && ($extension != "jpeg") && ($extension != "png") && ($extension != "gif")){
               $change='<div class="msgdiv">Unknown Image extension </div> ';
               $errors=1;
           }
           else{
                    $size=filesize($_FILES['image1']['tmp_name']);
                    if ($size > MAX_SIZE*1024){  
                      $change='<div class="msgdiv">You have exceeded the size limit!</div> ';
                      $errors=1;
                    }
                    if($extension=="jpg" || $extension=="jpeg" ){
                       $uploadedfile1 = $_FILES['image1']['tmp_name'];
                       $src = imagecreatefromjpeg($uploadedfile1);
                    }
                    else if($extension=="png"){
                            $uploadedfile1 = $_FILES['image1']['tmp_name'];
                            $src = imagecreatefrompng($uploadedfile1);
                    }
                    else {
                          $src = imagecreatefromgif($uploadedfile1);
                    }
                    echo $scr;
                    list($width,$height)=getimagesize($uploadedfile1);
                    $newwidth=900;
                    $newheight=($height/$width)*$newwidth;
                    $newwidth1=339;
                    $newheight1=226;
                    $newwidth2=36;
                    $newheight2=36;
                    $tmp=imagecreatetruecolor($newwidth,$newheight);
                    $tmp1=imagecreatetruecolor($newwidth1,$newheight1);
                    $tmp2=imagecreatetruecolor($newwidth2,$newheight2);

                    imagecopyresampled($tmp,$src,0,0,0,0,$newwidth,$newheight,$width,$height);
                    imagecopyresampled($tmp1,$src,0,0,0,0,$newwidth1,$newheight1,$width,$height);
                    imagecopyresampled($tmp2,$src,0,0,0,0,$newwidth2,$newheight2,$width,$height);

                    $filename = "../banquet/large/".$image1;
                    $filename1 = "../banquet/sm/".$image1;
                    $filename2 = "../banquet/xs/".$image1;

                    imagejpeg($tmp,$filename,100);
                    imagejpeg($tmp1,$filename1,100);
                    imagejpeg($tmp2,$filename2,100);

                    imagedestroy($src);
               }
         }
}

if($_SERVER["REQUEST_METHOD"] == "POST"){
$g112=end(explode('.',$_FILES['image2']['name']));
$image2='banquet_'.md5(rand()).'.'.$g112;
$uploadedfile2 = $_FILES['image2']['tmp_name'];
   if ($image2){
             $filename = stripslashes($_FILES['image2']['name']);
             $extension = getExtension($filename);
           $extension = strtolower($extension);
           if (($extension != "jpg") && ($extension != "jpeg") && ($extension != "png") && ($extension != "gif")){
               $change='<div class="msgdiv">Unknown Image extension </div> ';
               $errors=1;
           }
           else{
                    $size=filesize($_FILES['image2']['tmp_name']);
                    if ($size > MAX_SIZE*1024){  
                      $change='<div class="msgdiv">You have exceeded the size limit!</div> ';
                      $errors=1;
                    }
                    if($extension=="jpg" || $extension=="jpeg" ){
                       $uploadedfile2 = $_FILES['image2']['tmp_name'];
                       $src = imagecreatefromjpeg($uploadedfile2);
                    }
                    else if($extension=="png"){
                            $uploadedfile2 = $_FILES['image2']['tmp_name'];
                            $src = imagecreatefrompng($uploadedfile2);
                    }
                    else {
                          $src = imagecreatefromgif($uploadedfile2);
                    }
                    echo $scr;
                    list($width,$height)=getimagesize($uploadedfile2);
                    $newwidth=900;
                    $newheight=($height/$width)*$newwidth;
                    $newwidth1=339;
                    $newheight1=226;
                    $newwidth2=36;
                    $newheight2=36;
                    $tmp=imagecreatetruecolor($newwidth,$newheight);
                    $tmp1=imagecreatetruecolor($newwidth1,$newheight1);
                    $tmp2=imagecreatetruecolor($newwidth2,$newheight2);

                    imagecopyresampled($tmp,$src,0,0,0,0,$newwidth,$newheight,$width,$height);
                    imagecopyresampled($tmp1,$src,0,0,0,0,$newwidth1,$newheight1,$width,$height);
                    imagecopyresampled($tmp2,$src,0,0,0,0,$newwidth2,$newheight2,$width,$height);

                    $filename = "../banquet/large/".$image2;
                    $filename1 = "../banquet/sm/".$image2;
                    $filename2 = "../banquet/xs/".$image2;

                    imagejpeg($tmp,$filename,100);
                    imagejpeg($tmp1,$filename1,100);
                    imagejpeg($tmp2,$filename2,100);

                    imagedestroy($src);
               }
         }
}

if($_SERVER["REQUEST_METHOD"] == "POST"){
$g113=end(explode('.',$_FILES['image3']['name']));
$image3='banquet_'.md5(rand()).'.'.$g113;
$uploadedfile3 = $_FILES['image3']['tmp_name'];
   if ($image3){
             $filename = stripslashes($_FILES['image3']['name']);
             $extension = getExtension($filename);
           $extension = strtolower($extension);
           if (($extension != "jpg") && ($extension != "jpeg") && ($extension != "png") && ($extension != "gif")){
               $change='<div class="msgdiv">Unknown Image extension </div> ';
               $errors=1;
           }
           else{
                    $size=filesize($_FILES['image3']['tmp_name']);
                    if ($size > MAX_SIZE*1024){  
                      $change='<div class="msgdiv">You have exceeded the size limit!</div> ';
                      $errors=1;
                    }
                    if($extension=="jpg" || $extension=="jpeg" ){
                       $uploadedfile3 = $_FILES['image3']['tmp_name'];
                       $src = imagecreatefromjpeg($uploadedfile3);
                    }
                    else if($extension=="png"){
                            $uploadedfile3 = $_FILES['image3']['tmp_name'];
                            $src = imagecreatefrompng($uploadedfile3);
                    }
                    else {
                          $src = imagecreatefromgif($uploadedfile3);
                    }
                    echo $scr;
                    list($width,$height)=getimagesize($uploadedfile3);
                    $newwidth=900;
                    $newheight=($height/$width)*$newwidth;
                    $newwidth1=339;
                    $newheight1=226;
                    $newwidth2=36;
                    $newheight2=36;
                    $tmp=imagecreatetruecolor($newwidth,$newheight);
                    $tmp1=imagecreatetruecolor($newwidth1,$newheight1);
                    $tmp2=imagecreatetruecolor($newwidth2,$newheight2);

                    imagecopyresampled($tmp,$src,0,0,0,0,$newwidth,$newheight,$width,$height);
                    imagecopyresampled($tmp1,$src,0,0,0,0,$newwidth1,$newheight1,$width,$height);
                    imagecopyresampled($tmp2,$src,0,0,0,0,$newwidth2,$newheight2,$width,$height);

                    $filename = "../banquet/large/".$image3;
                    $filename1 = "../banquet/sm/".$image3;
                    $filename2 = "../banquet/xs/".$image3;

                    imagejpeg($tmp,$filename,100);
                    imagejpeg($tmp1,$filename1,100);
                    imagejpeg($tmp2,$filename2,100);

                    imagedestroy($src);
               }
         }
}

if($_SERVER["REQUEST_METHOD"] == "POST"){
$g114=end(explode('.',$_FILES['image4']['name']));
$image4='banquet_'.md5(rand()).'.'.$g114;
$uploadedfile4 = $_FILES['image4']['tmp_name'];
   if ($image4){
             $filename = stripslashes($_FILES['image4']['name']);
             $extension = getExtension($filename);
           $extension = strtolower($extension);
           if (($extension != "jpg") && ($extension != "jpeg") && ($extension != "png") && ($extension != "gif")){
               $change='<div class="msgdiv">Unknown Image extension </div> ';
               $errors=1;
           }
           else{
                    $size=filesize($_FILES['image4']['tmp_name']);
                    if ($size > MAX_SIZE*1024){  
                      $change='<div class="msgdiv">You have exceeded the size limit!</div> ';
                      $errors=1;
                    }
                    if($extension=="jpg" || $extension=="jpeg" ){
                       $uploadedfile4 = $_FILES['image4']['tmp_name'];
                       $src = imagecreatefromjpeg($uploadedfile4);
                    }
                    else if($extension=="png"){
                            $uploadedfile4 = $_FILES['image4']['tmp_name'];
                            $src = imagecreatefrompng($uploadedfile4);
                    }
                    else {
                          $src = imagecreatefromgif($uploadedfile4);
                    }
                    echo $scr;
                    list($width,$height)=getimagesize($uploadedfile4);
                    $newwidth=900;
                    $newheight=($height/$width)*$newwidth;
                    $newwidth1=339;
                    $newheight1=226;
                    $newwidth2=36;
                    $newheight2=36;
                    $tmp=imagecreatetruecolor($newwidth,$newheight);
                    $tmp1=imagecreatetruecolor($newwidth1,$newheight1);
                    $tmp2=imagecreatetruecolor($newwidth2,$newheight2);

                    imagecopyresampled($tmp,$src,0,0,0,0,$newwidth,$newheight,$width,$height);
                    imagecopyresampled($tmp1,$src,0,0,0,0,$newwidth1,$newheight1,$width,$height);
                    imagecopyresampled($tmp2,$src,0,0,0,0,$newwidth2,$newheight2,$width,$height);

                    $filename = "../banquet/large/".$image4;
                    $filename1 = "../banquet/sm/".$image4;
                    $filename2 = "../banquet/xs/".$image4;

                    imagejpeg($tmp,$filename,100);
                    imagejpeg($tmp1,$filename1,100);
                    imagejpeg($tmp2,$filename2,100);

                    imagedestroy($src);
               }
         }
}

if($_SERVER["REQUEST_METHOD"] == "POST"){
$g115=end(explode('.',$_FILES['image5']['name']));
$image5='banquet_'.md5(rand()).'.'.$g115;
$uploadedfile5 = $_FILES['image5']['tmp_name'];
   if ($image5){
             $filename = stripslashes($_FILES['image5']['name']);
             $extension = getExtension($filename);
           $extension = strtolower($extension);
           if (($extension != "jpg") && ($extension != "jpeg") && ($extension != "png") && ($extension != "gif")){
               $change='<div class="msgdiv">Unknown Image extension </div> ';
               $errors=1;
           }
           else{
                    $size=filesize($_FILES['image5']['tmp_name']);
                    if ($size > MAX_SIZE*1024){  
                      $change='<div class="msgdiv">You have exceeded the size limit!</div> ';
                      $errors=1;
                    }
                    if($extension=="jpg" || $extension=="jpeg" ){
                       $uploadedfile5 = $_FILES['image5']['tmp_name'];
                       $src = imagecreatefromjpeg($uploadedfile5);
                    }
                    else if($extension=="png"){
                            $uploadedfile5 = $_FILES['image5']['tmp_name'];
                            $src = imagecreatefrompng($uploadedfile5);
                    }
                    else {
                          $src = imagecreatefromgif($uploadedfile5);
                    }
                    echo $scr;
                    list($width,$height)=getimagesize($uploadedfile5);
                    $newwidth=900;
                    $newheight=($height/$width)*$newwidth;
                    $newwidth1=339;
                    $newheight1=226;
                    $newwidth2=36;
                    $newheight2=36;
                    $tmp=imagecreatetruecolor($newwidth,$newheight);
                    $tmp1=imagecreatetruecolor($newwidth1,$newheight1);
                    $tmp2=imagecreatetruecolor($newwidth2,$newheight2);

                    imagecopyresampled($tmp,$src,0,0,0,0,$newwidth,$newheight,$width,$height);
                    imagecopyresampled($tmp1,$src,0,0,0,0,$newwidth1,$newheight1,$width,$height);
                    imagecopyresampled($tmp2,$src,0,0,0,0,$newwidth2,$newheight2,$width,$height);

                    $filename = "../banquet/large/".$image5;
                    $filename1 = "../banquet/sm/".$image5;
                    $filename2 = "../banquet/xs/".$image5;

                    imagejpeg($tmp,$filename,100);
                    imagejpeg($tmp1,$filename1,100);
                    imagejpeg($tmp2,$filename2,100);

                    imagedestroy($src);
               }
         }
}

if($_SERVER["REQUEST_METHOD"] == "POST"){
$g116=end(explode('.',$_FILES['image6']['name']));
$image6='banquet_'.md5(rand()).'.'.$g116;
$uploadedfile6 = $_FILES['image6']['tmp_name'];
   if ($image6){
             $filename = stripslashes($_FILES['image6']['name']);
             $extension = getExtension($filename);
           $extension = strtolower($extension);
           if (($extension != "jpg") && ($extension != "jpeg") && ($extension != "png") && ($extension != "gif")){
               $change='<div class="msgdiv">Unknown Image extension </div> ';
               $errors=1;
           }
           else{
                    $size=filesize($_FILES['image6']['tmp_name']);
                    if ($size > MAX_SIZE*1024){  
                      $change='<div class="msgdiv">You have exceeded the size limit!</div> ';
                      $errors=1;
                    }
                    if($extension=="jpg" || $extension=="jpeg" ){
                       $uploadedfile6 = $_FILES['image6']['tmp_name'];
                       $src = imagecreatefromjpeg($uploadedfile6);
                    }
                    else if($extension=="png"){
                            $uploadedfile6 = $_FILES['image6']['tmp_name'];
                            $src = imagecreatefrompng($uploadedfile6);
                    }
                    else {
                          $src = imagecreatefromgif($uploadedfile6);
                    }
                    echo $scr;
                    list($width,$height)=getimagesize($uploadedfile6);
                    $newwidth=900;
                    $newheight=($height/$width)*$newwidth;
                    $newwidth1=339;
                    $newheight1=226;
                    $newwidth2=36;
                    $newheight2=36;
                    $tmp=imagecreatetruecolor($newwidth,$newheight);
                    $tmp1=imagecreatetruecolor($newwidth1,$newheight1);
                    $tmp2=imagecreatetruecolor($newwidth2,$newheight2);

                    imagecopyresampled($tmp,$src,0,0,0,0,$newwidth,$newheight,$width,$height);
                    imagecopyresampled($tmp1,$src,0,0,0,0,$newwidth1,$newheight1,$width,$height);
                    imagecopyresampled($tmp2,$src,0,0,0,0,$newwidth2,$newheight2,$width,$height);

                    $filename = "../banquet/large/".$image6;
                    $filename1 = "../banquet/sm/".$image6;
                    $filename2 = "../banquet/xs/".$image6;

                    imagejpeg($tmp,$filename,100);
                    imagejpeg($tmp1,$filename1,100);
                    imagejpeg($tmp2,$filename2,100);

                    imagedestroy($src);
               }
         }
}

if($_SERVER["REQUEST_METHOD"] == "POST"){
$g117=end(explode('.',$_FILES['image7']['name']));
$image7='banquet_'.md5(rand()).'.'.$g117;
$uploadedfile7 = $_FILES['image7']['tmp_name'];
   if ($image7){
             $filename = stripslashes($_FILES['image7']['name']);
             $extension = getExtension($filename);
           $extension = strtolower($extension);
           if (($extension != "jpg") && ($extension != "jpeg") && ($extension != "png") && ($extension != "gif")){
               $change='<div class="msgdiv">Unknown Image extension </div> ';
               $errors=1;
           }
           else{
                    $size=filesize($_FILES['image7']['tmp_name']);
                    if ($size > MAX_SIZE*1024){  
                      $change='<div class="msgdiv">You have exceeded the size limit!</div> ';
                      $errors=1;
                    }
                    if($extension=="jpg" || $extension=="jpeg" ){
                       $uploadedfile7 = $_FILES['image7']['tmp_name'];
                       $src = imagecreatefromjpeg($uploadedfile7);
                    }
                    else if($extension=="png"){
                            $uploadedfile7 = $_FILES['image7']['tmp_name'];
                            $src = imagecreatefrompng($uploadedfile7);
                    }
                    else {
                          $src = imagecreatefromgif($uploadedfile7);
                    }
                    echo $scr;
                    list($width,$height)=getimagesize($uploadedfile7);
                    $newwidth=900;
                    $newheight=($height/$width)*$newwidth;
                    $newwidth1=339;
                    $newheight1=226;
                    $newwidth2=36;
                    $newheight2=36;
                    $tmp=imagecreatetruecolor($newwidth,$newheight);
                    $tmp1=imagecreatetruecolor($newwidth1,$newheight1);
                    $tmp2=imagecreatetruecolor($newwidth2,$newheight2);

                    imagecopyresampled($tmp,$src,0,0,0,0,$newwidth,$newheight,$width,$height);
                    imagecopyresampled($tmp1,$src,0,0,0,0,$newwidth1,$newheight1,$width,$height);
                    imagecopyresampled($tmp2,$src,0,0,0,0,$newwidth2,$newheight2,$width,$height);

                    $filename = "../banquet/large/".$image7;
                    $filename1 = "../banquet/sm/".$image7;
                    $filename2 = "../banquet/xs/".$image7;

                    imagejpeg($tmp,$filename,100);
                    imagejpeg($tmp1,$filename1,100);
                    imagejpeg($tmp2,$filename2,100);

                    imagedestroy($src);
               }
         }
}

if($_SERVER["REQUEST_METHOD"] == "POST"){
$g118=end(explode('.',$_FILES['image8']['name']));
$image8='banquet_'.md5(rand()).'.'.$g118;
$uploadedfile8 = $_FILES['image8']['tmp_name'];
   if ($image8){
             $filename = stripslashes($_FILES['image8']['name']);
             $extension = getExtension($filename);
           $extension = strtolower($extension);
           if (($extension != "jpg") && ($extension != "jpeg") && ($extension != "png") && ($extension != "gif")){
               $change='<div class="msgdiv">Unknown Image extension </div> ';
               $errors=1;
           }
           else{
                    $size=filesize($_FILES['image8']['tmp_name']);
                    if ($size > MAX_SIZE*1024){  
                      $change='<div class="msgdiv">You have exceeded the size limit!</div> ';
                      $errors=1;
                    }
                    if($extension=="jpg" || $extension=="jpeg" ){
                       $uploadedfile8 = $_FILES['image8']['tmp_name'];
                       $src = imagecreatefromjpeg($uploadedfile8);
                    }
                    else if($extension=="png"){
                            $uploadedfile8 = $_FILES['image8']['tmp_name'];
                            $src = imagecreatefrompng($uploadedfile8);
                    }
                    else {
                          $src = imagecreatefromgif($uploadedfile8);
                    }
                    echo $scr;
                    list($width,$height)=getimagesize($uploadedfile8);
                    $newwidth=900;
                    $newheight=($height/$width)*$newwidth;
                    $newwidth1=339;
                    $newheight1=226;
                    $newwidth2=36;
                    $newheight2=36;
                    $tmp=imagecreatetruecolor($newwidth,$newheight);
                    $tmp1=imagecreatetruecolor($newwidth1,$newheight1);
                    $tmp2=imagecreatetruecolor($newwidth2,$newheight2);

                    imagecopyresampled($tmp,$src,0,0,0,0,$newwidth,$newheight,$width,$height);
                    imagecopyresampled($tmp1,$src,0,0,0,0,$newwidth1,$newheight1,$width,$height);
                    imagecopyresampled($tmp2,$src,0,0,0,0,$newwidth2,$newheight2,$width,$height);

                    $filename = "../banquet/large/".$image8;
                    $filename1 = "../banquet/sm/".$image8;
                    $filename2 = "../banquet/xs/".$image8;

                    imagejpeg($tmp,$filename,100);
                    imagejpeg($tmp1,$filename1,100);
                    imagejpeg($tmp2,$filename2,100);

                    imagedestroy($src);
               }
         }
}

if($_SERVER["REQUEST_METHOD"] == "POST"){
$g119=end(explode('.',$_FILES['image9']['name']));
$image9='banquet_'.md5(rand()).'.'.$g119;
$uploadedfile9 = $_FILES['image9']['tmp_name'];
   if ($image9){
             $filename = stripslashes($_FILES['image9']['name']);
             $extension = getExtension($filename);
           $extension = strtolower($extension);
           if (($extension != "jpg") && ($extension != "jpeg") && ($extension != "png") && ($extension != "gif")){
               $change='<div class="msgdiv">Unknown Image extension </div> ';
               $errors=1;
           }
           else{
                    $size=filesize($_FILES['image9']['tmp_name']);
                    if ($size > MAX_SIZE*1024){  
                      $change='<div class="msgdiv">You have exceeded the size limit!</div> ';
                      $errors=1;
                    }
                    if($extension=="jpg" || $extension=="jpeg" ){
                       $uploadedfile9 = $_FILES['image9']['tmp_name'];
                       $src = imagecreatefromjpeg($uploadedfile9);
                    }
                    else if($extension=="png"){
                            $uploadedfile9 = $_FILES['image9']['tmp_name'];
                            $src = imagecreatefrompng($uploadedfile9);
                    }
                    else {
                          $src = imagecreatefromgif($uploadedfile9);
                    }
                    echo $scr;
                    list($width,$height)=getimagesize($uploadedfile9);
                    $newwidth=900;
                    $newheight=($height/$width)*$newwidth;
                    $newwidth1=339;
                    $newheight1=226;
                    $newwidth2=36;
                    $newheight2=36;
                    $tmp=imagecreatetruecolor($newwidth,$newheight);
                    $tmp1=imagecreatetruecolor($newwidth1,$newheight1);
                    $tmp2=imagecreatetruecolor($newwidth2,$newheight2);

                    imagecopyresampled($tmp,$src,0,0,0,0,$newwidth,$newheight,$width,$height);
                    imagecopyresampled($tmp1,$src,0,0,0,0,$newwidth1,$newheight1,$width,$height);
                    imagecopyresampled($tmp2,$src,0,0,0,0,$newwidth2,$newheight2,$width,$height);

                    $filename = "../banquet/large/".$image9;
                    $filename1 = "../banquet/sm/".$image9;
                    $filename2 = "../banquet/xs/".$image9;

                    imagejpeg($tmp,$filename,100);
                    imagejpeg($tmp1,$filename1,100);
                    imagejpeg($tmp2,$filename2,100);

                    imagedestroy($src);
               }
         }
}


$c_s="SELECT * FROM banquet where name ='$banquet' and city='$city' "or die(mysqli_error());
$c_q=mysqli_query($con,$c_s)or die(mysqli_error());
$c_f=mysqli_num_rows($c_q);
if($c_f == 1){
  echo "<script>alert('Banquet already exist','_self');</script>";
  echo "<script>window.open('banquet.php','_self')</script>";
  exit();

}
     $sql="INSERT INTO  banquet VALUES ('','$banquet','$city','$title','$para1','$para2','$image1','$image2','$image3','$image4','$image5','$image6','$image7','$image8','$image9','$para3','$location','$disp','$banq','$deco')" or die(mysqli_error());
     $run=mysqli_query($con,$sql) or die(mysqli_error());
     if($run){
              echo "<script>alert('Banquet inserted successfully','_self');</script>";
              echo "<script>window.open('banquet.php','_self')</script>";

             }
     else{
          echo "<script>alert('Data not inserted.');</script>";
         }
}
?>