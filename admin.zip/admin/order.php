<?php
include('session.php');
?>

<body>
     <div class="container"><br>
          <div class="row-fluid">
               <div class="span12">
                    <div class="span12">
                         <div class="alert alert-success">
                               <h4>Consult Details </h4>
                         </div>
                         <legend></legend>
                         <table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" id="example">
                         <caption></caption>
                         <thead>
                               <tr>
                                <th>Name</th>
                                  <th>DOB</th>
                                  <th>Height/Weight</th>
                                  <th>Email/No.</th>
                                  <th>Medicine used/Allergies</th>
                                  <th>Description</th>
                                  <th>Address</th>
                                  <th>Occupation</th>
                                  <th>Gender</th>
                                  <th>Product/Price</th>
                                  <th>Date</th>
                                  <th>Payment</th>
                                  <th>Status</th>



                                  

                              </tr>
                        </thead>
                        <tbody>
                              <?php
                                    $query="SELECT * from register where status!='done'" or die(mysqli_error());
                                    $sql=mysqli_query($con,$query);
                                    while($row=mysqli_fetch_array($sql)){
                                    
                                ?>
                               <tr>
                                  <td><?php echo $row['nm']; ?></td>
                                  <td><?php echo $row['dob']; ?></td>
                                  <td><?php echo $row['weight']; ?> /</br><?php echo $row['height']; ?></td>
                                  <td><?php echo $row['em']; ?> /</br><?php echo $row['no']; ?></td>
                                  <td><?php echo $row['med']; ?> /</br><?php echo $row['allergies']; ?></td>
                                  <td><?php echo $row['des']; ?></td>
                                  <td><?php echo $row['adds']; ?></td>
                                  <td><?php echo $row['occu']; ?></td>
                                  <td><?php echo $row['gen']; ?></td>
                                  <td><?php echo $row['pnm']; ?> /</br><?php echo $row['pri']; ?></td>
                                  <td><?php echo $row['dt']; ?></td>
                                  <td><?php echo $row['payment']; ?></td>

                                  

                                  
                                  
                                  <td><a  href="invoice.php?inv=<?php echo $row[0];?>"  class="btn btn-warning" ><i class="icon-pencil icon-large"></i>&nbsp; Delivered</a>
                                  
                                  
                                 

                                  </td> 
                                  
                               </tr>
                               <?php }  ?>

                         </tbody>
                         </table>
                    </div> 
                    
                   
              </div>
                            <?php if($genco == $transco){ ?>
                    <div class="well">
                         <a button class="btn btn-block btn-success" type="button" href="#profit" role="button"  data-toggle="modal"><i class="icon-book"></i> Profit Statement</button></a>
                   <?php include('order_modal_profit.php'); ?>
                   </div> 
                   <?php } ?>
         </div>
    </div>
</body>
<?php include('footer.php'); ?>


 













