<div class="span3">  
     <div class="alert alert-success">
	     Welcome:
	        <?php 
              $User_ID=$_SESSION['Username'];
              include('dbcon.php');
              $result="select * from login where user_name='$User_ID'";
              $row=mysqli_query($con,$result) or die(mysqli_error());
              $run=mysqli_fetch_array($row);
              $Full_Name=$run[3];
              echo $Full_Name; 
            ?>
	   </div>
	   <div class="well">
	   <a button class="btn btn-block btn-danger" type="button" href="#myModal" role="button"  data-toggle="modal"><i class="icon-signout icon-large"></i> Sign Out</button></a>
	   <?php include("logout_modal.php");?>
	   </div>