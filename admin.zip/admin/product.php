<?php
include('session.php');
?>
<div class="navbar navbar-inverse">
     <div class="navbar-inner">
          <ul class="nav"> 
              <li class="divider-vertical"></li><li class="divider-vertical"></li><li class="divider-vertical"></li>
              <li class="divider-vertical"></li>
              <li><a href="admin.php">Admin</a></li> <li class="divider-vertical"></li>
              <li  class="active"><a href="#">Customer</a></li> <li class="divider-vertical"></li>
              <li><a href="gallery_add.php">Gallery</a></li>  <li class="divider-vertical"></li>
              <li><a href="order.php">Orders</a></li>  <li class="divider-vertical"></li>
              <li><a href="sales.php">Sales</a></li>  <li class="divider-vertical"></li>
              <li><a href="payment.php">Payment</a></li> <li class="divider-vertical"></li>
          </ul>
     </div>
</div>
<body>
     <div class="container"><br>
          <div class="row-fluid">
               <div class="span12">
                    <div class="span9">
                         <div class="alert alert-success">
                               <h4>Customer Details </h4>
                         </div>
                         <legend></legend>
                         <table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" id="example">
                         <caption></caption>
                         <thead>
                               <tr>
                                  <th>Name</th>
                                  <th>Email</th>
                                  <th>Password</th>
                                  <th>Contact</th>
                                  <th>country</th>
                                  <th>city</th>
                                  <th>Address</th>
                                  <th>Zip Code</th>
                              </tr>
                        </thead>
                        <tbody>
                              <?php
                                    $query="SELECT * from customer " or die(mysqli_error());
                                    $sql=mysqli_query($con,$query);
                                    while($row=mysqli_fetch_array($sql)){
                                    
                                ?>
                               <tr>
                                  <td><?php echo $row[1]; ?></td>
                                  <td><?php echo $row[2]; ?></td>
                                  <td><?php echo $row[3]; ?></td>
                                  <td><?php echo $row[6]; ?></td>
                                  <td><?php echo $row[4]; ?></td>
                                  <td><?php echo $row[5]; ?></td>
                                  <td><?php echo $row[7]; ?></td>
                                  <td><?php echo $row[8]; ?></td>
                                   
                               </tr>
                               <?php
                                    
                              }  ?>
                         </tbody>
                         </table>
                    </div> 
                    <?php include('session_sidebar.php'); ?>
              </div>
         </div>
    </div>
</body>
<?php include('footer.php'); ?>


 













