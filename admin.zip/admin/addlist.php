<?php 
include('session.php');
?>
<div class="navbar navbar-inverse">
     <div class="navbar-inner">
          <ul class="nav"> 
              <li class="divider-vertical"></li><li class="divider-vertical"></li><li class="divider-vertical"></li>
              <li class="divider-vertical"></li>
              <li><a href="admin.php">Admin</a></li> <li class="divider-vertical"></li>
              <li><a href="banquet.php">Banquet</a></li>  <li class="divider-vertical"></li>
              <li><a href="banquet_option.php">Option</a></li>  <li class="divider-vertical"></li>
              <li><a href="catering.php">Catering</a></li>  <li class="divider-vertical"></li>
              <li><a href="catering_package.php">Package</a></li>  <li class="divider-vertical"></li>
              <li><a href="catering_category.php">Category</a></li>  <li class="divider-vertical"></li>
              <li class="active"><a href="#">Add to List</a></li> <li class="divider-vertical"></li>
              <li><a href="banquet_book.php">Booking</a></li>  <li class="divider-vertical"></li>
              <li><a href="banquet_delist.php">Delist</a></li>  <li class="divider-vertical"></li>
              <li><a href="banquet_booking.php">Booked</a></li>  <li class="divider-vertical"></li>
          </ul>
     </div>
</div>
<body>
     <div class="container"><br>
          <div class="row-fluid">
               <div class="span12">
                    <div class="span9">
                         <div class="alert alert-success">
                               <h4>Caterer Items List</h4>
                         </div>
                         <legend></legend>
                         <table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" id="example">
                         <caption></caption>
                         <thead>
                               <tr>
                                  <th>Banquet</th>
                                  <th>Items</th>
                                  <th>Category</th>
                                  <th width="180">Action</th>
                              </tr>
                        </thead>
                        <tbody>
                              <?php
                                    $query="SELECT * from catering_banquet " or die(mysqli_error());
                                    $sql=mysqli_query($con,$query);
                                    while($row=mysqli_fetch_array($sql)){
                                    $id1=$row[0];
                                    $bid=$row[1];
                                    $cid=$row[2];
                                    $query1="SELECT * from banquet where id='$bid' " or die(mysqli_error());
                                    $sql1=mysqli_query($con,$query1);
                                    $row1=mysqli_fetch_array($sql1);
                                    $query2="SELECT * from catering where id='$cid' " or die(mysqli_error());
                                    $sql2=mysqli_query($con,$query2);
                                    $row2=mysqli_fetch_array($sql2);
                                ?>
                               <tr>
                                  <td><?php echo $row1[1]; ?></td>
                                  <td><?php echo $row2[1]; ?></td>
                                  <td><?php echo $row2[2]; ?></td>
                                  <td width="180">
                                      <a data-toggle="modal" href="#<?php echo 'dbcatering'.$id1; ?>" class='btn btn-danger'>  <i class="icon-trash icon-large"></i>&nbsp;Delete</a>                                     
                                  </td> 
                               </tr>
                               <?php
                                    include('modal_delete_bcatering.php');
                              }  ?>
                         </tbody>
                         </table>
                    </div> 
                    <?php include('session_sidebar.php'); ?>
                    <div class="well">
                         <a button class="btn btn-block btn-success" type="button" href="#addphotos" role="button"  data-toggle="modal"><i class="icon-pencil"></i> Add Item</button></a>
                   <?php include('modal_add_catering_banquet.php'); ?>
                   </div>
              </div>
         </div>
    </div>
</body>
<?php include('footer.php'); ?>