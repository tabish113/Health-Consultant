<div id="<?php echo 'del'.$id7; ?>" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
     <div class="modal-header">
     </div>
     <div class="modal-body">
          <div class="alert alert-gray">Are you Sure you Want to <strong>Delete?</strong></div>
    </div>
    <div class="modal-footer">
         <a href="delete_admin.php<?php echo '?id='.$id7; ?>" class="btn btn-danger"><i class="icon-trash"></i>&nbsp;Yes</a>
	     <button class="btn" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i>&nbsp;Close</button>
    </div>
</div>



