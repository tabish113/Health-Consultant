<?php
include('session.php');
?>

<body>
     <div class="container"><br>
          <div class="row-fluid">
               <div class="span12">
                    <div class="span9">
                         <div class="alert alert-success">
                               <h4>Delivered Details </h4>
                         </div>
                         <legend></legend>
                         <table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" id="example">
                         <caption></caption>
                         <thead>
                               <tr>
                                  <th>Invoice</th>
                                  <th>Customer</th>
                                  <th>Address</th>
                                  <th>Action</th>
                                  

                              </tr>
                        </thead>
                        <tbody>
                              <?php
                                    $query="SELECT * from customer_order_details where status='Delivered'" or die(mysqli_error($con));
                                    $sql=mysqli_query($con,$query);
                                    while($row=mysqli_fetch_array($sql)){
                                    $c_id=$row[1];
                                    $p_id=$row[2];
                                    $sql_p=mysqli_query($con,"SELECT * from product where id='$p_id' ") or die(mysqli_error($con));
                                    $row_p=mysqli_fetch_array($sql_p);
                                    $sql_c=mysqli_query($con,"SELECT * from customer_orders where cust_id='$c_id' ") or die(mysqli_error($con));
                                    $row_c=mysqli_fetch_array($sql_c);
                                    //amount
                      $total=0;
                      $query8="SELECT * from customer_orders where invoice='$c_id' and cust_id='$p_id' " or die(mysqli_error($con));
                      $sql8=mysqli_query($con,$query8);
                      while($row8=mysqli_fetch_array($sql8)){
                      $total+=$row8[6];
                      }
                                    //amount end
                                    
                                ?>
                               <tr>
                                  <td><?php echo $row[0]; ?></td>
                                  <td><?php echo $row[3]; ?></td>
                                  <td><?php echo 'Address : '.$row[4].'<br>Pin : '.$row[5].'<br>Phone : '.$row[6].'<br>Date : '.$row[7];?><br>Amount : <span class="fa fa-rupee"></span>  <?php echo $total; ?></td>
                                  <td><a  href="invoice.php?inv=<?php echo $row[0];?>"  class="btn btn-warning" ><i class="icon-pencil icon-large"></i>&nbsp; order</a>

                                  </td> 
                                  
                               </tr>
                               <?php }  ?>

                         </tbody>
                         </table>
                    </div>  
                    <?php include('session_sidebar.php'); ?>
                    <div class="well">
                         <a button class="btn btn-block btn-success" type="button" href="#addphotos" role="button"  data-toggle="modal"><i class="icon-book"></i> Statement</button></a>
                   <?php include('order_modal_statement.php'); ?>
                   </div> 
                    
                   
              </div>
                            <?php if($genco == $transco){ ?>
                    <div class="well">
                         <a button class="btn btn-block btn-success" type="button" href="#profit" role="button"  data-toggle="modal"><i class="icon-book"></i> Profit Statement</button></a>
                   <?php include('order_modal_profit.php'); ?>
                   </div> 
                   <?php } ?>
         </div>
    </div>
</body>
<?php include('footer.php'); ?>















