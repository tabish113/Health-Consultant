<?php
session_start();
include('dbcon.php');

?>
<!DOCTYPE html>
<html>
<head>
      <title>Jharkhand Diet</title>
      <link rel="shortcut icon" href="../slider/favi.png">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link rel="stylesheet" type="text/css" href="css/DT_bootstrap.css">
      <link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="screen">
      <link href="css/bootstrap-responsive.css" rel="stylesheet" type="text/css" media="screen">
      <link href="css/font-awesome.css" rel="stylesheet" type="text/css" media="screen">
      <script src="js/jquery.js" type="text/javascript"></script>
      <script src="js/bootstrap.js" type="text/javascript"></script>
      <script type="text/javascript" charset="utf-8" language="javascript" src="js/jquery.dataTables.js"></script>
      <script type="text/javascript" charset="utf-8" language="javascript" src="js/DT_bootstrap.js"></script>
      <link href="../css/fonts.css" rel="stylesheet" type="text/css">

            <!-- CSS -->
</head>      

<div class="navbar navbar-inverse navber-fixed-top" >
     <div class="navbar-inner" style="background:#34495E;">
          <a class="brand" ></a> 
         <h3 style="color:#fff;"> <center>Jharkhand Diet | Welcome Admin</center></h3>
              <ul class="nav">

              </ul>
     </div>
</div>
<div class="container">
     <body>
          <div class="row-fluid">
               <div class="span12"><br>
                    <div class="span3">
                    </div>
                    <div class="span6"><br><br>
	                       <div class="well">
	                           <legend>
	                                   <div class="alert alert-success"><h4>Sign In</h4> </div>
                              </legend>
                              <form action="index.php" class="form-horizontal" method="POST">
                                    <div class="control-group">
                                          <label class="control-label" for="inputEmail">Username</label>
                                                 <div class="controls">
                                                     <input type="text" id="inputEmail" name="Username" placeholder="Username" class="span8" required>
                                                 </div>
                                      </div>
                                      <div class="control-group">
                                           <label class="control-label" for="inputPassword">Password</label>
                                                  <div class="controls">
                                                         <input type="password" id="inputPassword" name="Password" placeholder="Password" class="span8" required>
                                                    </div>
                                     </div>
                                     <div class="control-group">
                                            <div class="controls">
                                                 <button style="background:#34495E;" type="submit" name="login" class="btn btn-success"><i class="icon-signin"></i>&nbsp;Sign in</button>
                                            </div>
                                     </div>
                               </form>
                          </div>
                    </div>
              </div>
        </div>
   </body>
   <?php include('footer.php');  ?>
</div>
<?php 
if(isset($_POST['login'])){   
$name=($_POST['Username']);
$pass=($_POST['Password']);
$sql="SELECT * FROM login where user_name='$name' AND user_password='$pass'";
$run = mysqli_query($con,$sql) or die(mysqli_error($con));
if(mysqli_num_rows($run)>0){
    $_SESSION['Username']=$name;
    echo "<script>window.open('admin.php?logged=login successfully','_self')</script>";
}
else {
       echo "<script>alert('name and password not matched')</script>";
}
} 
?>