<?php
include('session.php');
$to1=$_POST['category1'];
$to2=$_POST['category2'];

?>

<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="css/main.css" rel="stylesheet" type="text/css">

<style>
@media print { @page { margin: 0; } body { margin: 1.6cm; } }
</style>
<div class="navbar navbar-inverse">
     <div class="navbar-inner">
          <ul class="nav"> 
              <li class="divider-vertical"></li><li class="divider-vertical"></li><li class="divider-vertical"></li>
              <li class="divider-vertical"></li>
              <li><a href="admin.php">Admin</a></li> <li class="divider-vertical"></li>
              <li><a href="gallery_add.php">Grocery</a></li>  <li class="divider-vertical"></li>
              <li><a href="order.php">Orders</a></li>  <li class="divider-vertical"></li>
              <li><a href="Delivered.php">Delivered</a></li>  <li class="divider-vertical"></li>
              <li  ><a href="cancelled.php">Cancelled</a></li>  <li class="divider-vertical"></li>
              <li><a href="grocery_danger.php">Danger</a></li>  <li class="divider-vertical"></li>
              <li><a href="grocery_hidden.php">Hidden</a></li>  <li class="divider-vertical"></li>
              <li><a href="grocery_stock.php">Out of Stock</a></li>  <li class="divider-vertical"></li>
          </ul>
     </div>
</div>
<body>
     <div class="container" id="mydiv">
          <div class="row-fluid">
               <div class="span12">
                    <div class="span12">
                         <legend></legend>



        <!-- main -->                        
      <div class="content">
        <div class="main-content">
          <!-- INVOICE -->
          <div class="invoice">
            <!-- invoice header -->
            <div class="invoice-header">
              <div class="row">
                <div class="col-lg-3 col-print-3">
                  <img src="../img/Raftaa.png" alt="Raafta Logo" width="100"/>
                </div>
                <div class="col-lg-9 col-print-9">
                  <ul class="list-inline">
                    <li>Invoice : <strong><?php echo $to1.' - To - '.$to2; ?></strong></li>
                  </ul>
                </div>
              </div>
            </div>
            <!-- end invoice header -->
            <!-- invoice item table -->
            <div class="table-responsive" style="margin-top:-50px;">
              <table class="table invoice-table">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Address</th>
                    <th>Phone</th>
                    <th>Invoice</th>
                    <th>Amount to be Collected</th>
                    <th>Signature</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                      $i=0;
                      $mrp=0;
                      $query8="SELECT * from customer_order_details where id > $to1 and id < $to2 and status!='Cancelled' " or die(mysqli_error());
                      $sql8=mysqli_query($con,$query8);
                      while($row8=mysqli_fetch_array($sql8)){
                      $total=0;
                      $c_id=$row8[1];
                      $p_id=$row8[2];
                      $query6="SELECT * from customer_orders where invoice='$c_id' and cust_id='$p_id' " or die(mysqli_error());
                      $sql6=mysqli_query($con,$query6);
                      while($row6=mysqli_fetch_array($sql6)){
                      $total+=$row6[6]; }
                      $i+=1;
                    ?>
                  <tr>
                    <td><?php echo $i; ?></td>
                    <td><?php echo $row8[3]; ?></td>
                    <td><?php echo $row8[4].' '.$row8[5]; ?></td>
                    <td><?php echo $row8[6]; ?></td>
                    <td><?php echo $row8[0]; ?></td>
                    <td><span class="fa fa-rupee"></span> <?php echo $total; ?></td>
                    <td style="text-align:left;"> </td>
                  </tr>
                  <?php } ?>
                </tbody>
              </table>
            </div>
            <!-- end invoice item table -->
            <!-- invoice footer -->
            <div class="invoice-footer">
              <div class="row">
                <div class="col-sm-5 col-sm-offset-1 col-print-4 col-print-offset-2 right-col">
                  <div class="invoice-total">
                    <div class="row">
                      <div class="col-xs-4 col-xs-offset-4 col-print-6 col-print-offset-2">
                        
                      </div>
                      <div class="col-xs-4 text-right col-print-4">
                        
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-sm-12 col-print-12 left-col" style="text-align:center;">
                    <strong>Thankyou for giving us this wonderful opportunity to serve you.</strong><br>
                    <strong>Truly it is our pleasure.</strong><br>
                    <strong>You are a valuable customer to us.</strong>
                </div>
                <div class="col-sm-6 col-print-6 left-col">
                  <blockquote class="invoice-notes">
                    <strong></strong>
                    <p></p>
                  </blockquote>
                </div>
              </div>
            </div>
            <!-- end invoice footer -->
            <!-- invoice action buttons -->
            <div class="invoice-buttons">
              <button class="btn btn-custom-primary print-btn"><i class="icon icon-print icon-large"></i> Print</button>
            </div>
            <!-- end invoice action buttons -->
          </div>
          <!-- INVOICE -->
        </div>
      </div>
      <!-- /main -->




                    </div> 
                   
              </div>
         </div>
    </div>
  <script >

$('.print-btn').click( function(){
window.print();
  });
  </script>
</body>
<?php include('footer.php'); ?>