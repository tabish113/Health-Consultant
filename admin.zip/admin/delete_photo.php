<?php 
include('dbcon.php');
$id=$_GET['id'];

$query="SELECT * from product where id='$id' " or die(mysqli_error($con));
$sql=mysqli_query($con,$query);
$row=mysqli_fetch_array($sql);
$img2=$row[2];
$img3=$row[3];
$img4=$row[4];
$img5=$row[5];
$img6=$row[6];
$img7=$row[7];


unlink("../product/xl/".$img2);
unlink("../product/".$img2);


mysqli_query($con,"DELETE  from product where id='$id'")or die(mysql_error());
header('location:add_product.php');
?>