<?php 

include('session.php');

?>


<body>

     <div class="container"><br>

          <div class="row-fluid">

               <div class="span12">

                    <div class="span9">

                         <div class="alert alert-success">

                               <h4>Product List</h4>

                         </div>

                         <legend></legend>

                         <table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered">

                         <caption></caption>
                         <thead>
                               <tr>
                                  <th colspan="1">
                                  Search : <input type="text" id="search">
                                  </th>
                                  <th colspan="1">
                                  <button class="btn btn-block btn-success"   onclick="searchon()"><i class="icon-search"></i> Search</button>
                                  </th>
                                  <th colspan="1">
                                  </th>
                              </tr>
                               <tr>
                                  <th style="text-align:center;">Title</th>
                                  <th style="text-align:center;">Price</th>
                                  <th style="text-align:center;">Action</th>
                              </tr>
                        </thead>

                        <tbody id="result">

                        </tbody>

                         </table>

                    </div> 

                    <?php include('session_sidebar.php'); ?>

                    <div class="well">

                         <a button class="btn btn-block btn-success" type="button" href="#addphotos" role="button"  data-toggle="modal"><i class="icon-pencil"></i> Add Product</button></a>

                   <?php include('modal_addphotos.php'); ?>

                   </div>

              </div>

         </div>

    </div>

</body>

<?php include('footer.php'); ?>
<script>
function searchon(){
  var srch= document.getElementById("search").value;
  $.post("grocery_alli.php",{id:srch},function(data){

  $("#result").html(data);  });
}
</script>