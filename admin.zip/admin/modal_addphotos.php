<div id="addphotos" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
     <div class="modal-header">
          <div class="alert alert-gray">
               Add New Product
          </div>
          <div class="modal-body"><hr>
               <form class="form-horizontal" method="POST" enctype="multipart/form-data">
                     <div class="control-group">
                           <label class="control-label" for="inputEmail">Name</label>
                                  <div class="controls">
                                       <input type="text" class="span10" id="inputEmail" name="title" placeholder="Title" required class="span3">
                                  </div>
                     </div>
                     <div class="control-group">
                          <label class="control-label" for="input01">Image 1</label>
                                 <div class="controls">
                                      <input type="file" name="image1" class="font"> 
                                 </div>
                     </div>
                     
                     <div class="control-group">
                          <label class="control-label" for="inputEmail">MRP</label>
                                 <div class="controls">
                                      <input type="text" class="span10" id="inputEmail" name="mrp" placeholder="MRP" required class="span3">

                                 </div>
                     </div>
                    

                     <div class="control-group">
                          <label class="control-label" for="inputEmail">Selling Price</label>
                                 <div class="controls">
                                      <input type="text" class="span10" id="inputEmail" name="price" placeholder="Selling Price" required class="span3">
                                 </div>
                     </div>

                     <div class="control-group">
                          <label class="control-label" for="inputEmail">GST</label>
                                 <div class="controls">
                                      <input type="text" class="span10" id="inputEmail" name="gst" placeholder="GST" required class="span3">
                                 </div>
                     </div>

                     <div class="control-group">
                          <label class="control-label" for="inputEmail">Category</label>
                                 <div class="controls">
                                      <select name="category" required> 
                                                             <option value="null">Select</option>
                                                             <?php
                                                  $cat_select="SELECT * FROM category ";
                                                  $cat_query=mysqli_query($con,$cat_select);
                                                  while($cat_fetch=mysqli_fetch_array($cat_query)){
                                                             $cat_nm=$cat_fetch['nm'];
                                                             $cat_lnk=$cat_fetch['lnk'];

                                                             ?>
                                                             <option  value="<?php echo $cat_lnk;?>"><?php echo $cat_nm;?></option>
                                                             
                                                             <?php }?>
                                             
                                             
                                     </select>
                                </div>
                     </div>
                     
                      <div class="control-group">
                          <label class="control-label" for="inputEmail">Status</label>
                                 <div class="controls">
                                      <select name="status"> 
                                             
                                                             <option  value="stock">Stock</option>
                                             
                                                             <option value="out of stock">Out of Stock</option>
                                                            
                                             </optgroup>
                                     </select>
                                </div>
                     </div>
                     
                     <div class="control-group">
                          <label class="control-label" for="inputEmail">Description</label>
                                 <div class="controls">
                                      <textarea rows="5" class="span10"  placeholder="Write your details here..!" name="content"></textarea>
                                 </div>
                    </div>
               </div>
               <div class="modal-footer">
                     <button name="save" type="submit" class="btn btn-success"><i class="icon-pencil"></i>&nbsp;Post</button>
                     <button class="btn" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i>&nbsp;Close</button>
              </form>  
      </div>
</div>
<?php
     include('dbcon.php');
     if(isset($_POST['save'])){
     $title=$_POST['title'];

error_reporting(0);
$change="";
$abc="";
define ("MAX_SIZE","400");
function getExtension($str) {
         $i = strrpos($str,".");
         if (!$i) { return ""; }
         $l = strlen($str) - $i;
         $ext = substr($str,$i+1,$l);
         return $ext;
}
$errors=0;
if($_SERVER["REQUEST_METHOD"] == "POST"){
$g111=end(explode('.',$_FILES['image1']['name']));
$image1='item_'.md5(rand()).'.'.$g111;
$uploadedfile1 = $_FILES['image1']['tmp_name'];
   if ($image1){
             $filename = stripslashes($_FILES['image1']['name']);
             $extension = getExtension($filename);
           $extension = strtolower($extension);
           if (($extension != "jpg") && ($extension != "jpeg") && ($extension != "png") && ($extension != "gif")){
               $change='<div class="msgdiv">Unknown Image extension </div> ';
               $errors=1;
           }
           else{
                    $size=filesize($_FILES['image1']['tmp_name']);
                   
                    if($extension=="jpg" || $extension=="jpeg" ){
                       $uploadedfile1 = $_FILES['image1']['tmp_name'];
                       $src = imagecreatefromjpeg($uploadedfile1);
                    }
                    else if($extension=="png"){
                            $uploadedfile1 = $_FILES['image1']['tmp_name'];
                            $src = imagecreatefrompng($uploadedfile1);
                    }
                    else {
                          $src = imagecreatefromgif($uploadedfile1);
                    }
                    echo $scr;
                    list($width,$height)=getimagesize($uploadedfile1);
                    $newwidth=2048;
                    $newheight=2048;
                    $newwidth1=300;
                    $newheight1=200;
                    
                    $tmp=imagecreatetruecolor($newwidth,$newheight);
                    $tmp1=imagecreatetruecolor($newwidth1,$newheight1);
                    
                    imagecopyresampled($tmp,$src,0,0,0,0,$newwidth,$newheight,$width,$height);
                    imagecopyresampled($tmp1,$src,0,0,0,0,$newwidth1,$newheight1,$width,$height);
                    
                    $filename = "../product/xl/".$image1;
                    $filename1 = "../product/".$image1;
                    

                    imagejpeg($tmp,$filename,100);
                    imagejpeg($tmp1,$filename1,100);
                    

                    imagedestroy($src);
               }
         }
}


     $price=$_POST['price'];
     $mrp=$_POST['mrp'];
     $cat=$_POST['category'];
     $des=$_POST['content'];
     $status=$_POST['status'];
     $gst=$_POST['gst'];


     $sql="INSERT INTO product(nm,img1,mrp,price,feature,cat,status,gst) VALUES ('$title','$image1','$mrp','$price','$des','$cat','$status','$gst')" or die(mysqli_error());
     $run=mysqli_query($con,$sql) or die(mysqli_error());
     if($run){
              echo "<script>alert('New Record Inserted Successfully','_self');</script>";
              echo "<script>window.open('add_product.php','_self')</script>";

             }
     else{
          echo "<script>alert('Data not Inserted.');</script>";
         }
}
?>