<?php
include("dbcon.php");
$pro=$_POST['id'];
                                    $query="SELECT * from product where nm like '%".$pro."%' " or die(mysqli_error());

                                    $sql=mysqli_query($con,$query);

                                    while($row=mysqli_fetch_array($sql)){

                                    $id1=$row['id'];

                                    $title1=$row['nm'];

                                    $image1=$row['img1'];

                                    $price=$row['price'];

                                    $cat=$row['cat'];
                                    $mrp=$row['mrp'];
                                    $cp=$row['cp'];
                                    $gst=$row['gst'];



                                    



                                    $content=substr($row['feature'],0,100);

                                ?>

                               <tr>

                                  <td><b><?php echo $title1;?></b><br>

                                    

                                     Category : <?php echo $cat;?><br>


                                  </td>

                                  <td>

                                      MRP : <span class="fa fa-rupee"></span> <?php echo $mrp;?><br>

                                      CP : <span class="fa fa-rupee"></span> <?php echo $cp;?><br>

                                      SP : <span class="fa fa-rupee"></span> <?php echo $price;?><br>

                                      GST : <?php echo $gst;?> %<br>

                                   

                                  </td>

                                  <td width="180">

                                      <a href="grocery_allj.php?id=<?php echo $id1; ?>"  class="btn btn-warning" ><i class="icon-pencil icon-large"></i>&nbsp; Edit</a>

                                      <a href="grocery_allk.php?id=<?php echo $id1; ?>" class='btn btn-danger'>  <i class="icon-trash icon-large"></i>&nbsp;Delete</a>                                     

                                  </td> 

                               </tr>

                               <?php

                                    include('modal_delete_photo.php');

                                    include('edit_photos.php');

                              }  ?>

                         </tbody>