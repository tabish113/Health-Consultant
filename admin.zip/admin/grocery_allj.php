<?php 

include('session.php');
$idf=$_GET['id'];
$query="SELECT * from product where id='$idf' " or die(mysqli_error());
$sql=mysqli_query($con,$query);
$row=mysqli_fetch_array($sql);
?>


<body>

     <div class="container"><br>

          <div class="row-fluid">

               <div class="span12">

                    <div class="span9">

                         <div class="alert alert-success">

                               <h4>Product List</h4>

                         </div>

                         <legend></legend>

     <div class="modal-header">

          <div class="modal-body">

               <form class="form-horizontal" method="POST" enctype="multipart/form-data">

                     <div class="control-group">

                           <label class="control-label" for="inputEmail">Name</label>

                                  <div class="controls">

                                       <input name="id5" value="<?php echo $row['id']?>" type="hidden" id="inputEmail" placeholder="ID">

                                       <input type="text" value="<?php echo $row['nm']; ?>" class="span10" id="inputEmail" name="nm" placeholder="Title" required class="span3">

                                  </div>

                     </div>

                     <div class="control-group">

                          <label class="control-label" for="input01">Image 1</label>

                                 <div class="controls">

                                      <input type="hidden" name="img1" value="<?php echo $row['img1']; ?>" class="font">

                                      <input type="file" name="image1" class="font"> 

                                 </div>

                     </div>

                   

                     <div class="control-group">

                          <label class="control-label" for="inputEmail">MRP</label>

                                 <div class="controls">

                                      <input type="text" value="<?php echo $row['mrp']; ?>" class="span10" id="inputEmail" name="mrp" placeholder="MRP" required class="span3">

                                 </div>

                     </div>

                     <div class="control-group">

                          <label class="control-label" for="inputEmail">Cost Price</label>

                                 <div class="controls">

                                      <input type="text" value="<?php echo $row['cp']; ?>" class="span10" id="inputEmail" name="cp" placeholder="Cost Price" required class="span3">

                                 </div>

                     </div>

                     <div class="control-group">

                          <label class="control-label" for="inputEmail">Selling Price</label>

                                 <div class="controls">

                                      <input type="text" value="<?php echo $row['price']; ?>" class="span10" id="inputEmail" name="sp" placeholder="Selling Price" required class="span3">

                                 </div>

                     </div>

                     <div class="control-group">

                          <label class="control-label" for="inputEmail">GST %</label>

                                 <div class="controls">

                                      <input type="number" value="<?php echo $row['gst']; ?>" class="span10" id="inputEmail" name="gst" placeholder="GST %" required class="span3">

                                 </div>

                     </div>

                  


                     <div class="control-group">

                          <label class="control-label" for="inputEmail">Category</label>

                                 <div class="controls">

                                      <select name="cat"> 
                                                             <option value="<?php echo $row['cat']; ?>"><?php echo $row['cat']; ?></option>
                                                             <?php
                                                  $cat_select="SELECT * FROM category ";
                                                  $cat_query=mysqli_query($con,$cat_select);
                                                  while($cat_fetch=mysqli_fetch_array($cat_query)){
                                                             $cat_nm=$cat_fetch['nm'];
                                                             $cat_lnk=$cat_fetch['lnk'];

                                                             ?>
                                                             <option  value="<?php echo $cat_lnk;?>"><?php echo $cat_nm;?></option>
                                                             
                                                             <?php }?>


                                     </select>

                                </div>

                     </div>

                         <div class="control-group">
                                 <label class="control-label" for="inputEmail">Special</label>
                                                <div class="controls">
                                                  <select name="special"> 
                                                             <option value="<?php echo $row['special']; ?>"><?php echo $row['special']; ?></option>
                                                             
                                                             <option  value="special">special</option>
                                                             <option  value="remove">remove</option>

                                                         </select>
                                                               </div>  </div>
                    


                      <div class="control-group">

                          <label class="control-label" for="inputEmail">Status</label>

                                 <div class="controls">

                                      <select name="status"> 

                                                             <option value="<?php echo $row['status']; ?>"><?php echo $row['status']; ?></option>

                                             

                                                             <option value="out of stock">Out of Stock</option>

                                             

                                                             <option  value="stock">Stock</option>

                                                             <option  value="hide">Hide</option>



                                             </optgroup>

                                     </select>

                                </div>

                     </div> 

                     

                     <div class="control-group">

                          <label class="control-label" for="inputEmail">Description</label>

                                 <div class="controls">

                                      <textarea rows="5" class="span10"  placeholder="Write your details here..!" name="des"><?php echo $row['feature']; ?></textarea>

                                 </div>

                    </div>

               </div>
               </div>

               <div class="modal-footer">

                     <button name="save1" type="submit" class="btn btn-success"><i class="icon-pencil"></i>&nbsp;Update</button>

              </form>  

      </div>

                    </div> 

                    <?php include('session_sidebar.php'); ?>

                    <div class="well">

                         <a button class="btn btn-block btn-success" type="button" href="#addphotos" role="button"  data-toggle="modal"><i class="icon-pencil"></i> Add Product</button></a>

                   <?php include('modal_addphotos.php'); ?>

                   </div>

              </div>

         </div>

    </div>

</body>

 
<?php
include('footer.php');
     if(isset($_POST['save1'])){

     $id6=$_POST['id5'];

     $nm=$_POST['nm'];



$imag1=$_POST['img1'];


error_reporting(0);

$change="";

$abc="";

define ("MAX_SIZE","400");

function getExtension($str) {

         $i = strrpos($str,".");

         if (!$i) { return ""; }

         $l = strlen($str) - $i;

         $ext = substr($str,$i+1,$l);

         return $ext;

}

$errors=0;



if($_FILES['image1']['name'] == ''){ 

$image1=$imag1;

}

else{

$image1=$imag1;

unlink("../product/xl/".$image1);

unlink("../product/".$image1);




if($_SERVER["REQUEST_METHOD"] == "POST"){

$g111=end(explode('.',$_FILES['image1']['name']));

$image1='item_'.md5(rand()).'.'.$g111;

$uploadedfile1 = $_FILES['image1']['tmp_name'];

   if ($image1){

             $filename = stripslashes($_FILES['image1']['name']);

             $extension = getExtension($filename);

           $extension = strtolower($extension);

           if (($extension != "jpg") && ($extension != "jpeg") && ($extension != "png") && ($extension != "gif")){

               $change='<div class="msgdiv">Unknown Image extension </div> ';

               $errors=1;

           }

           else{

                    $size=filesize($_FILES['image1']['tmp_name']);

                  

                    if($extension=="jpg" || $extension=="jpeg" ){

                       $uploadedfile1 = $_FILES['image1']['tmp_name'];

                       $src = imagecreatefromjpeg($uploadedfile1);

                    }

                    else if($extension=="png"){

                            $uploadedfile1 = $_FILES['image1']['tmp_name'];

                            $src = imagecreatefrompng($uploadedfile1);

                    }

                    else {

                          $src = imagecreatefromgif($uploadedfile1);

                    }

                    echo $scr;

                    list($width,$height)=getimagesize($uploadedfile1);

                    $newwidth=2048;

                    $newheight=2048;

                    $newwidth1=300;

                    $newheight1=200;

                    

                    $tmp=imagecreatetruecolor($newwidth,$newheight);

                    $tmp1=imagecreatetruecolor($newwidth1,$newheight1);


                    imagecopyresampled($tmp,$src,0,0,0,0,$newwidth,$newheight,$width,$height);

                    imagecopyresampled($tmp1,$src,0,0,0,0,$newwidth1,$newheight1,$width,$height);


                    $filename = "../product/xl/".$image1;

                    $filename1 = "../product/".$image1;

                   

                    imagejpeg($tmp,$filename,100);

                    imagejpeg($tmp1,$filename1,100);

                    imagedestroy($src);

               }

         }

}     

}

     $sp=$_POST['sp'];
    $mrp=$_POST['mrp'];
     $status=$_POST['status'];
     $cat=$_POST['cat'];
     $des=$_POST['des'];
     $cp=$_POST['cp'];
     $gst=$_POST['gst'];
     $special=$_POST['special'];

    


     $sql45="UPDATE product SET nm='$nm',img1='$image1',mrp='$mrp',price='$sp',cp='$cp',feature='$des',cat='$cat',status='$status',gst='$gst',special='$special'  where id='$id6'" or die(mysqli_error());

     $run45=mysqli_query($con,$sql45) or die(mysqli_error($con));



     if($run45){

              echo "<script>alert('Product updated successfully');</script>";

              echo "<script>window.open('add_product.php','_self')</script>";



             }

}

?>