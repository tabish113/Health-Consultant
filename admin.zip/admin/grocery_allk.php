<?php 

include('session.php');
$id1=$_GET['id'];

?>


<body>

     <div class="container"><br>

          <div class="row-fluid">

               <div class="span12">

                    <div class="span9">

                         <div class="alert alert-success">

                               <h4>Product List</h4>

                         </div>

                         <legend></legend>

                         <div class="modal-header">
     </div>
     <div class="modal-body">
          <div class="alert alert-gray">Are you Sure you Want to <strong>Delete?</strong></div>
    </div>
    <div class="modal-footer">
         <a href="delete_photo.php<?php echo '?id='.$id1; ?>" class="btn btn-danger"><i class="icon-trash"></i>&nbsp;Yes</a>
	     <a class="btn" href="grocery_all.php"><i class="icon-remove"></i>&nbsp;Close</a>
    </div>

                    </div> 

                    <?php include('session_sidebar.php'); ?>

                    <div class="well">

                         <a button class="btn btn-block btn-success" type="button" href="#addphotos" role="button"  data-toggle="modal"><i class="icon-pencil"></i> Add Product</button></a>

                   <?php include('modal_addphotos.php'); ?>

                   </div>

              </div>

         </div>

    </div>

</body>

<?php include('footer.php'); ?>
<script>
function searchon(){
  var srch= document.getElementById("search").value;
  $.post("grocery_alli.php",{id:srch},function(data){

  $("#result").html(data);  });
}
</script>