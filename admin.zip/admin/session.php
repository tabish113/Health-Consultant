<?php
session_start();
if (!isset($_SESSION['Username'])){
header('location:index.php?error=you are not admin');
}
include('dbcon.php');
include('header.php');
$genco=$_SESSION['Username'];
$transco='khazamashakamoto';
?>