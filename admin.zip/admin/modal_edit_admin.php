<div id="edit<?php echo  $id7; ?>" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
     <div class="modal-header">
          <div class="alert alert-gray">
	           Edit Admin
          </div>
          <div class="modal-body"><hr>
               <form class="form-horizontal" method="POST">
                     <div class="control-group">
                           <label class="control-label" for="inputEmail">Full Name</label>
                                   <div class="controls">
                                        <input name="id" value="<?php echo $row['id']?>" type="hidden" id="inputEmail" placeholder="ID">
                                        <input name="fname" value="<?php echo $row['Full_Name']; ?>" type="text" id="inputPassword" placeholder="Password">
                                   </div>
                    </div>
                    <div class="control-group">
                         <label class="control-label" for="inputPassword">Username</label>
                                 <div class="controls">
                                      <input name="un" value="<?php echo $row['user_name']; ?>" type="text" id="inputEmail" placeholder="UserName"> 
                                 </div>
                    </div>
	                <div class="control-group">
                         <label class="control-label" for="inputPassword">Password</label>
                                 <div class="controls">
                                        <input name="pw" value="<?php echo $row['user_password']; ?>" type="text" id="inputPassword" placeholder="Password">                                     
                                 </div>
                   </div>
                   <div class="control-group">
                        <div class="controls">
	                          <div class="modal-footer">
	                               <button name="edit" type="submit" class="btn btn-large btn-warning"><i class="icon-save"></i>&nbsp;Save</button>
	                               <button class="btn btn-large" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i>&nbsp;No</button>
                               </div>
                         </div>
                   </div>
             </form>
       </div>
	   <?php
	        if (isset($_POST['edit'])){
	        $id = $_POST['id'];
	        $un = $_POST['un'];
	        $pw = $_POST['pw'];
	        $name = $_POST['fname'];
	        mysqli_query($con,"UPDATE login set user_name = '$un' , user_password = '$pw', Full_Name='$name' where id = '$id' ")or die(mysql_error());
	        header('location:admin.php');
	   } ?>
	</div>
</div>