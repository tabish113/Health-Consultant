<?php
include("dbcon.php");
$idm=$_GET['inv'];
     $sql45="UPDATE  customer_order_details set status='Cancelled' where id='$idm'  " or die(mysqli_error($con));
     $run45=mysqli_query($con,$sql45) or die(mysqli_error($con));
     if($run45){
              echo "<script>alert('Order cancelled successfully','_self');</script>";
              echo "<script>window.open('order.php','_self')</script>";

             }

?>