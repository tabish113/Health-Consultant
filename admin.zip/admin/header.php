<!DOCTYPE html>
<html>
<head >
      <title>Dent Bazzar</title>
      <link rel="shortcut icon" href="../slider/favi.png">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link rel="stylesheet" type="text/css" href="css/DT_bootstrap.css">
      <link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="screen">
      <link href="css/bootstrap-responsive.css" rel="stylesheet" type="text/css" media="screen">
      <link href="css/font-awesome.css" rel="stylesheet" type="text/css" media="screen">
      <script src="js/jquery.js" type="text/javascript"></script>
      <script src="js/bootstrap.js" type="text/javascript"></script>
      <script type="text/javascript" charset="utf-8" language="javascript" src="js/jquery.dataTables.js"></script>
      <script type="text/javascript" charset="utf-8" language="javascript" src="js/DT_bootstrap.js"></script>
      <link href="../css/fonts.css" rel="stylesheet" type="text/css">
<div class="navbar navbar-inverse" >
     <div class="navbar-inner" style="background:#34495E;">
          <ul class="nav"> 
              <li class="divider-vertical"></li><li class="divider-vertical"></li><li class="divider-vertical"></li>
              <li class="divider-vertical"></li>
              <li  ><a href="admin.php">Admin</a></li> <li class="divider-vertical"></li>
             
              <li><a href="order.php">Consult</a></li>  <li class="divider-vertical"></li>
              
               <li><a href="Delivered.php">Delivered</a></li>  <li class="divider-vertical"></li>
              
              <li><a href="contact.php">Contact</a></li>  <li class="divider-vertical"></li>
             

          </ul>
     </div>
</div>

            <!-- CSS -->
</head>      
