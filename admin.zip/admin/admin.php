<?php
include('session.php');
?>

<body>
     <div class="container"><br>
          <div class="row-fluid">
                <div class="span12">
                     <div class="span9">
                           <div class="alert alert-success">
                                 <h4>Admin List</h4>
                           </div>
                           <legend></legend>
                           <table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" id="example">
                           <caption></caption>
                                    <thead>
                                           <tr>
                                              <th>Name</th>
                                              <th>Username</th>
                                              <th>Password</th>
                                              <th width="180">Action</th>
                                           </tr>
                                     </thead>
                                     <tbody>
                                           <?php
                                                $query="SELECT * from login" or die(mysqli_error($con));
                                                $sql=mysqli_query($con,$query)or die(mysqli_error($con));
                                                while($row=mysqli_fetch_array($sql)){
                                                $id7=$row['id'];
                                                $usr=$row['user_name'];
                                                $ps=$row['user_password'];
                                                $fn=$row['Full_Name'];
                                            ?>
                                            <tr>
                                              <td><?php echo $fn;?></td>
                                              <td><?php echo $usr;?></td>
                                              <td><?php echo $ps;?></td>
                                              <td width="180">
                                                  <a data-toggle="modal" href="#<?php echo 'edit'.$id7; ?>"  class="btn btn-warning" ><i class="icon-pencil icon-large"></i>&nbsp; Edit</a>
                                                  <a data-toggle="modal" href="#<?php echo 'del'.$id7; ?>" class='btn btn-danger'>  <i class="icon-trash icon-large"></i>&nbsp;Delete</a>
                                              </td> 
                                          </tr>
                                          <?php
                                               include('modal_edit_admin.php');
                                               include('modal_delete_admin.php');
                                           } ?> 
                                      </tbody> 
                              </table>    
                         </div>
                         <?php include('session_sidebar.php'); ?>
                         <div class="well">
                              <a button class="btn btn-block btn-success" type="button" href="#addadmin" role="button"  data-toggle="modal"><i class="icon-edit icon-large"></i> Add Admin</button></a>
                         <?php include("modal_addadmin.php");?>
                         </div>
                   </div>
             </div>
       </div>
</body>
<?php   include('footer.php'); ?>