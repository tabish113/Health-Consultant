<?php
include("dbcon.php");
 $id=$_GET['id_dn'];
 $update="UPDATE complain SET status='done' WHERE id='$id'";
$query=mysqli_query($con,$update);

if($query){
	

   echo "<script>alert('The complainant has been solved !..')</script>";
  echo "<script>window.open('redeem.php','_self')</script>";
  
}

?>