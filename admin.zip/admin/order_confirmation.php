<?php
include("dbcon.php");
$idm=$_GET['inv'];
     $sql45="UPDATE  customer_order_details set status='Delivered' where id='$idm'  " or die(mysqli_error($con));
     $run45=mysqli_query($con,$sql45) or die(mysqli_error($con));
     if($run45){




$no="SELECT * FROM customer_order_details where id='$idm' ";
$qo=mysqli_query($con,$no);
$fo=mysqli_fetch_array($qo);
$sen=$fo['cust_id'];
$inv=$fo['invoice'];


  $n="SELECT * FROM register where cno='$sen'";
$q=mysqli_query($con,$n);
$f=mysqli_fetch_array($q);

$total=0;
$no1="SELECT * FROM customer_orders where invoice='$inv' and cust_id='$sen' ";
$qo1=mysqli_query($con,$no1);
while($fo1=mysqli_fetch_array($qo1)){
	$p_id=$fo1['p_id'];
	$quan=$fo1['quan'];


$total+=$fo1[6];
$total1=$total/50;

}
$refer="UPDATE refer_amt SET amount='$total1',status='yes' WHERE order_id='$idm' ";
$refer_query=mysqli_query($con,$refer);

if($refer_query){
	

$refer_select="SELECT * FROM refer_amt where new_id='$sen' and order_id='$idm'";
$refer_query1=mysqli_query($con,$refer_select);
$refer_fetch=mysqli_fetch_array($refer_query1);
$c_id=$refer_fetch['c_id'];
$refer_amount=$refer_fetch['amount'];


  $n="SELECT * FROM register where cno='$c_id'";
$q=mysqli_query($con,$n);
$f=mysqli_fetch_array($q);
$refer_amount1=$f['refer_amount'];

$main_amt=$refer_amount+$refer_amount1;

$refer_r_sel="UPDATE register SET refer_amount='$main_amt' WHERE cno='$c_id'";
$refer_r_query1=mysqli_query($con,$refer_r_sel);


  $n2="SELECT * FROM register where cno='$sen'";
$q2=mysqli_query($con,$n2);
$f2=mysqli_fetch_array($q2);
$refer_amount2=$f2['refer_amount'];

$main_amt2=$total1+$refer_amount2;

$refer_r_sel2="UPDATE register SET refer_amount='$main_amt2' WHERE cno='$sen'";
$refer_r_query2=mysqli_query($con,$refer_r_sel2);

}


              echo "<script>alert('Order delivered successfully','_self');</script>";
              echo "<script>window.open('order.php','_self')</script>";

             }
?>